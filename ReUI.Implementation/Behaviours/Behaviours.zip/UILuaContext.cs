﻿using System;
using System.Collections.Generic;
using System.Linq;
using AOFG.Lua.Api;
using ReUI.Implementation.Converters;
using AOFG.View.Api;
using Rentitas;
using ReUI.Api;
using ReUI.Implementation.Tables;
using UnityEngine;
using XLua;

namespace ReUI.Implementation.Behaviours
{
    public class UILuaContext : UIViewBehaviour, ISetPools
    {
        private Pool<ILuaPool> _luaPool;

        private LuaTable _stateTable;
        private LuaTable _currentProps;
        private LuaTable _contextTable;

        private Pool<IUIPool> _uiPool;
        private Action _onPropsChanged;
        private Pool<IViewPool> _viewPool;

        public LuaTable Context
        {
            get
            {
                if (_contextTable == null)
                    RebuildContext();
                return _contextTable;
            }
        }

        protected override void Start()
        {
            base.Start();
            ListenInjector();
            RebuildContext();
        }

        private void ListenInjector()
        {
            GetComponentInParent<UILuaPropertiesInjector>()?.ListenInjection(Inject);
        }

        void OnDestroy()
        {
            _contextTable?.Dispose(true);
        }

        protected LuaEnv Environment => _luaPool.GetEnvironment();

        private void RebuildContext()
        {
            if(_contextTable == null)
                _contextTable = _luaPool.CreateContext();

            if (_currentProps == null)
                _currentProps = Environment.NewTable();

            if (_stateTable == null)
                _stateTable = Environment.NewTable();

            _contextTable.Set("state", _stateTable);
            _contextTable.Set("scope", ToScope(Element.Self));
            _contextTable.Set("props", _currentProps);
        }

        public void SetPools(Pools pools)
        {
            _luaPool = pools.Get<ILuaPool>();
            _uiPool = pools.Get<IUIPool>();
            _viewPool = pools.Get<IViewPool>();
        }

        public void Inject(LuaTable table)
        {
            _currentProps = table;
            if (IsReady)
            {
                RebuildContext();
                _onPropsChanged?.Invoke();
            }
        }

        internal LuaTable MakeContext(UIElement element, Dictionary<ExecutionMethod, string> code)
        {
            var table = _luaPool.CreateContext(Context);
//            table.SetMetaTable(Context);
            table.Set("self", ToTable(element.Self));
//            table.Set("self", element.Self.ToTable(_luaPool.GetEnvironment()));
            Environment.DoString(string.Join("\n", code.Values.ToArray()), element.Identity.ToString(), table);
            return table;
        }

        public ScopeTable ToScope(Entity<IUIPool> element)
        {
            return new ScopeTable(element, _uiPool, _viewPool);
//            var tbl = Environment.NewTable();
//            tbl.Set("__index", element);
//            tbl.Set("setProps", (Action<string, object>)((key, value) =>
//            {
//                Debug.Log($"update prop {key} with {value} on {element} ({element.Get<Api.Name>().Value}");
//                var props = element.Get<Properties>();
//                props.Value.SetInPath(key, value);
//                element.ReplaceInstance(props);
//
////                var parent = _uiPool.GetElement(element.Need<Api.Parent>().Id);
////                if (parent == null)
////                    return;
////                var props = parent.Need<Properties>();
////                if (props.Value == null)
////                    props.Value = Environment.NewTable();
//
////                props.Value.SetInPath(key, value);
////                parent.ReplaceInstance(props);
//            }));
//
//            return tbl;
        }

        public ElementTable ToTable(Entity<IUIPool> element)
        {
            return new ElementTable(element, _uiPool, _viewPool);
//            var tbl = Environment.NewTable();
//            tbl.Set("__index", element);
//            tbl.Set("id", element.Need<Element>().Id.ToString());
//            tbl.Set("name", element.Need<Api.Name>().Value);
//            tbl.Set("parent", (Func<LuaTable>)(() => ToTable(_uiPool.GetElement(element.Get<Api.Parent>().Id))));
//
//            tbl.Set("setPosition", (Action<float, float>)((x, y) => element.Replace<Position>(p => p.Value = new Vector2(x, y))));
//            tbl.Set("setMargin", (Action<float, float>)((x,y) => element.Replace<Margin>(m => m.Value = new Vector4(x,y,x,y))));
//            tbl.Set("setSize", (Action<float,float>)((x,y) => element.Replace<Size>(m => m.Value = new Vector2(x,y))));
//            tbl.Set("setColor", (Action<string>)(color => element.Replace<Api.Color>(c => c.Value = ColorConverter.Convert(color))));
//            tbl.Set("setText", (Action<string>)(text => element.Replace<Api.Text>(c => c.Value = text)));
//            
//
//            return tbl;
        }


        public void ListenProps(Action onProps)
        {
            _onPropsChanged += onProps;
            onProps();
        }
    }
}