﻿using AOFG.View.Api;

namespace ReUI.Implementation.Behaviours
{
    public abstract  class UIViewBehaviour : ViewBehaviour
    {
        private UIElement _cachedComponent;
        public UIElement Element => GetElement();

        private UIElement GetElement()
        {
            if (!_cachedComponent) _cachedComponent = GetComponent<UIElement>();
            return _cachedComponent;
        }
    }
}