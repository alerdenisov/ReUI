﻿using UnityEngine;

namespace ReUI.Implementation.Behaviours
{
    [ExecuteInEditMode]
    [RequireComponent(typeof(RectTransform))]
    public class AnotherExperimentWithRect : MonoBehaviour
    {
        public Vector2 Position;
        public Vector2 Size;
        public Vector2 Pivot;
        public Vector4 Margins;
        public Vector4 Anchors;

        void Update()
        {
            var rect = transform as RectTransform;

            rect.anchorMin = new Vector2(Anchors.x, Anchors.z);
            rect.anchorMax = new Vector2(Anchors.y, Anchors.w);

            rect.offsetMin = new Vector2(-Margins.w, -Margins.z);
            rect.offsetMax = new Vector2(Margins.y, Margins.x);

            rect.pivot = Pivot;
            rect.sizeDelta = new Vector2(Size.x - Margins.x - Margins.z, Size.y - Margins.y - Margins.w);

            rect.anchoredPosition = Position;
//            rect.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, Size.y);
//            rect.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, Size.x);
        }
    }
}