﻿using System;
using System.Collections.Generic;
using AOFG.View.Api;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using XLua;

namespace ReUI.Implementation.Behaviours
{
    [CSharpCallLua]
    public delegate void PointerFunc(PointerEventData data);

    [RequireComponent(typeof (UILuaExecutionBase))]
    [RequireComponent(typeof(UIElement))]
    public class UILuaPointer : UILuaExecutor, IPointerClickHandler, IPointerEnterHandler, IPointerExitHandler
    {
        private PointerFunc _onClick;
        private PointerFunc _onMouseOver;
        private PointerFunc _onMouseOut;


        protected override void Start()
        {
            base.Start();
            GetComponent<Graphic>().raycastTarget = true;

            if (Executor.HasMethod(ExecutionMethod.Click))
                Executor.Local.Get("Click", out _onClick);

            if (Executor.HasMethod(ExecutionMethod.MouseOver))
                Executor.Local.Get("MouseOver", out _onMouseOver);

            if (Executor.HasMethod(ExecutionMethod.MouseOut))
                Executor.Local.Get("MouseOut", out _onMouseOut);
        }

        public string OnMouseOutCode 
        {
            set
            {
                if(string.IsNullOrEmpty(value))
                    Executor.RemoveCode(ExecutionMethod.MouseOut);
                else
                    Executor.CreateCode(ExecutionMethod.MouseOut, value);
            }
        }

        public string OnClickCode
        {
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    Executor.RemoveCode(ExecutionMethod.Click);
                }
                else
                {
                    Executor.CreateCode(ExecutionMethod.Click, value);
                }
            }
        }

        public string OnMouseOverCode
        {
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    Executor.RemoveCode(ExecutionMethod.MouseOver);
                }
                else
                {
                    Executor.CreateCode(ExecutionMethod.MouseOver, value);
                }

            }
        }

        public void OnPointerClick(PointerEventData eventData)
        {
            _onClick?.Invoke(eventData);
        }

        public void OnPointerEnter(PointerEventData eventData)
        {
            _onMouseOver?.Invoke(eventData);
        }

        public void OnPointerExit(PointerEventData eventData)
        {
            _onMouseOut?.Invoke(eventData);

        }
    }
}