﻿using System;
using System.Collections.Generic;
using AOFG.View.Api;
using UnityEngine.EventSystems;
using XLua;

namespace ReUI.Implementation.Behaviours
{
    public enum ExecutionMethod
    {
        Click,
        MouseOver,
        MouseOut,

        Tick,
        Create,
        Destroy,

        PropertyInjection,
        Props,

        Itteration,
        Collection
    }

    public static class LuaCode
    {
        public static string Generate(ExecutionMethod method, string code)
        {
            switch (method)
            {
                case ExecutionMethod.Click:
                case ExecutionMethod.MouseOut:
                case ExecutionMethod.MouseOver:
                    return GeneratePointer(method, code);
                case ExecutionMethod.Props:
                case ExecutionMethod.PropertyInjection:
                case ExecutionMethod.Collection:
                case ExecutionMethod.Tick:
                    return GenerateParamless(method, code);
                case ExecutionMethod.Itteration:
                    return GenerateItteration(method, code);

            }

            throw new NotSupportedException($"Method {method} not supported yet..");
        }

        private static string GenerateItteration(ExecutionMethod method, string code)
        {
            return $@"
    function {method}(item, index)
        {code}
    end";
        }

        private static string GenerateParamless(ExecutionMethod method, string code)
        {
            return $@"
    function {method}() 
        {code} 
    end";
        }

        private static string GeneratePointer(ExecutionMethod method, string code)
        {
            return $@"
    function {method}(event) 
        {code} 
    end";
        }
    }

    public class UILuaExecutionBase : UIViewBehaviour
    {
        private Action<LuaTable> _onBuilded;
        private UILuaContext _cachedContext;
        private LuaTable _localTable;
        private Dictionary<ExecutionMethod, string> _code = new Dictionary<ExecutionMethod, string>();
        private bool _isBuilded;

        public UILuaContext Context => GetContext();

        public LuaTable Local => GetLocal();

        public bool HasMethod(ExecutionMethod type)
        {
            return _code.ContainsKey(type);
        }

        public void CreateCode(ExecutionMethod method, string code)
        {
            var luaCode = LuaCode.Generate(method, code);
            if (!_code.ContainsKey(method))
                _code.Add(method, string.Empty);

            _code[method] = luaCode;

            RequireRecompile();
        }

        public void RemoveCode(ExecutionMethod executionMethod)
        {
            if (!_code.ContainsKey(executionMethod))
                return;

            _code.Remove(executionMethod);
            RequireRecompile();
        }

        private void RequireRecompile()
        {
            _isBuilded = false;
        }

        private LuaTable GetLocal()
        {
            if (!_isBuilded)
            {
                _localTable = Context.MakeContext(Element, _code);
                _onBuilded?.Invoke(_localTable);
                _isBuilded = true;
            }

            return _localTable;
        }

        void OnDestroy()
        {
            _localTable?.Dispose(true);
        }

        private UILuaContext GetContext()
        {
            if (!_cachedContext) _cachedContext = GetComponentInParent<UILuaContext>();
            return _cachedContext;
        }

        public void AwaitBuilding(Action<LuaTable> onBuildedCallback)
        {
            if (_localTable != null)
                onBuildedCallback(_localTable);

            _onBuilded += onBuildedCallback;
        }

        private void Update()
        {
            GetLocal();
        }
    }
}