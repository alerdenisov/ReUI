﻿using System;
using System.Collections.Generic;
using System.Linq;
using AOFG.Lua.Api;
using Rentitas;
using ReUI.Api;
using UnityEngine;
using XLua;

namespace ReUI.Implementation.Behaviours
{
    [CSharpCallLua]
    public delegate LuaTable GetPropertyFunc();

    [RequireComponent(typeof(UILuaExecutionBase))]
    public class UILuaPropertiesInjector : UILuaExecutor, ISetPools
    {
        private GetPropertyFunc _injector;
        private Pool<ILuaPool> _luaPool;
        private LuaTable _currentProps;
        private Action<LuaTable> _propsListeners;

        public string PropertiesCode
        {
            set
            {
                if (string.IsNullOrEmpty(value))
                    Executor.RemoveCode(ExecutionMethod.PropertyInjection);
                else
                    Executor.CreateCode(ExecutionMethod.PropertyInjection, value);
            }
        }

        protected override void Start()
        {
            base.Start();

            if (Executor.HasMethod(ExecutionMethod.PropertyInjection))
            {
                Executor.Local.Get("PropertyInjection", out _injector);
                Executor.Context.ListenProps(InjectProps);
            }
        }
            
        private void InjectProps()
        {
            Element.Self.Replace<Properties>(props => props.Value = _injector?.Invoke() ?? _luaPool.GetEnvironment().NewTable());
            if (_injector != null)
            {
                _currentProps = _injector.Invoke() ?? _luaPool.GetEnvironment().NewTable();
                _propsListeners?.Invoke(_currentProps);
            }
        }

        public void ListenInjection(Action<LuaTable> action)
        {
            _propsListeners += action;
            if(_currentProps != null) action(_currentProps);
        }

        public void SetPools(Pools pools)
        {
            _luaPool = pools.Get<ILuaPool>();
        }
    }
}