﻿using System;
using Rentitas;
using ReUI.Api;
using UnityEngine;

namespace ReUI.Implementation.Behaviours
{
//    public class UIElement : ViewBehaviour, ISetPools
//    {
//        [SerializeField]
//        private Guid _identity;
//        private Pool<IUIPool> _uiPool;
//
//        public Guid Identity => _identity;
//
//        public Entity<IUIPool> Self => _uiPool.GetElement(Identity);
//
//        public void Setup(Guid id)
//        {
//            _identity = id;
//        }
//
//        public void SetPools(Pools pools)
//        {
//            _uiPool = pools.Get<IUIPool>();
//        }
//    }
}