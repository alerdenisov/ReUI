﻿using System;
using System.Collections.Generic;
using AOFG.View.Api;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using XLua;

namespace ReUI.Implementation.Behaviours
{
    [RequireComponent(typeof (UILuaExecutionBase))]
    [RequireComponent(typeof(UIElement))]
    public class UILuaUpdate : UILuaExecutor
    {
        private ParamlessFunc _onTick;

        protected override void Start()
        {
            base.Start();
            if (Executor.HasMethod(ExecutionMethod.Tick))
                Executor.Local.Get("Tick", out _onTick);
        }

        public string OnUpdateCode 
        {
            set
            {
                if(string.IsNullOrEmpty(value))
                    Executor.RemoveCode(ExecutionMethod.Tick);
                else
                    Executor.CreateCode(ExecutionMethod.Tick, value);
            }
        }

        public void Update()
        {
            _onTick?.Invoke();
        }
    }
}