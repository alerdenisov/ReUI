﻿using System;
using XLua;

namespace ReUI.Implementation.Behaviours
{
    [CSharpCallLua]
    public delegate void ParamlessFunc();
    
    public class UILuaProps : UILuaExecutor
    {
        private ParamlessFunc _onProps;
        private bool _needToRefresh;

        public string OnPropsCode
        {
            set
            {
                if (string.IsNullOrEmpty(value))
                    Executor.RemoveCode(ExecutionMethod.Props);
                else
                    Executor.CreateCode(ExecutionMethod.Props, value);
            }
        }

        public void OnProps()
        {
            if(_onProps == null)
                _needToRefresh = true;
            else
                _onProps.Invoke();
        }

        protected override void Start()
        {
            base.Start();
            Executor.AwaitBuilding(OnBuilded);
            Executor.Context.ListenProps(OnProps);
        }

        void Update()
        {
            if (!_needToRefresh || _onProps == null) return;

            _onProps();
            _needToRefresh = false;
        }

        private void OnBuilded(LuaTable luaTable)
        {
            if (Executor.HasMethod(ExecutionMethod.Props))
                luaTable.Get("Props", out _onProps);
        }
    }
}