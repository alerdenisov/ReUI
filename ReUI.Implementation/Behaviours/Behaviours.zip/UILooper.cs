﻿using System.Linq;
using AOFG.Lua.Api;
using Rentitas;
using ReUI.Api;
using ReUI.Implementation.Tables;
using UnityEngine;
using XLua;

namespace ReUI.Implementation.Behaviours
{
    [CSharpCallLua]
    public delegate LuaTable ItterationPropertyInjector(ElementTable item, int index);

    [CSharpCallLua]
    public delegate LuaTable CollectionFunc();

    public class UILooper : UILuaExecutor, ISetPools
    {
        private CollectionFunc _collection;
        private ItterationPropertyInjector _itteration;
        private Pool<IUIPool> _uiPool;
        private Pool<ILuaPool> _luaPool;

        public string ItterationCode
        {
            set
            {
                if(string.IsNullOrEmpty(value))
                    Executor.RemoveCode(ExecutionMethod.Itteration);
                else
                    Executor.CreateCode(ExecutionMethod.Itteration, value);
            }
        }

        public string CollectionCode
        {
            set
            {
                if(string.IsNullOrEmpty(value))
                    Executor.RemoveCode(ExecutionMethod.Collection);
                else
                    Executor.CreateCode(ExecutionMethod.Collection, value);
            }
        }

        public string ItemName { get; set; }

        protected override void Start()
        {
            base.Start();
            Executor.AwaitBuilding(OnBuilded);
        }

        private void OnBuilded(LuaTable obj)
        {
            obj.Get("Itteration", out _itteration);
            obj.Get("Collection", out _collection);

            var _itemsTable = _collection();

            var id = Element.Identity;
            foreach (var key in _itemsTable.GetKeys<int>())
            {
                var child = _uiPool.CreateChild(id);

                child.Add<Embed>(e => e.Name = ItemName);
                child.Add<Name>(n => n.Value = ItemName);
                child.Add<Properties>(prop =>
                {
                    var props = _itteration(Executor.Context.ToTable(child), key) ?? _luaPool.GetEnvironment().NewTable();
                    Debug.Log("Props to item: " + props);
                    prop.Value = props;
                });
            }
        }

        public void SetPools(Pools pools)
        {
            _luaPool = pools.Get<ILuaPool>();
            _uiPool = pools.Get<IUIPool>();
        }
    }
}