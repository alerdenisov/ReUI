﻿using UnityEngine;

namespace ReUI.Implementation.Behaviours
{
    [RequireComponent(typeof(UILuaExecutionBase))]
    public class UILuaExecutor : UIViewBehaviour
    {
        private UILuaExecutionBase _cachedExecution;

        protected UILuaExecutionBase Executor
        {
            get
            {
                if (!_cachedExecution)
                    _cachedExecution = GetComponent<UILuaExecutionBase>();
                return _cachedExecution;
            }
        }
    }
}