﻿using Uniful;
using UnityEngine;
using UnityEngine.Serialization;

namespace ReUI.Implementation.Behaviours
{
    [ExecuteInEditMode]
    public class ExperimentWithRectTransform : MonoBehaviour
    {
        public enum PFlags
        {
            Top         = 1 << 0,
            Bottom      = 1 << 1,
            Middle      = 1 << 2,

            Left        = 1 << 3,
            Center      = 1 << 4,
            Right       = 1 << 5
        }

        public enum AnchorType
        {
            Free,
            Stretch,
            Min,
            Middle,
            Max
        }

        private int Anchor(int x, int y) { return AnchorX(x) | AnchorY(y); }
        private int AnchorY(int flag) {  return (int)flag << 4; }
        private int AnchorX(int flag) {  return (int)flag; }

        public enum PivotType
        {
            Free,

            TopLeft         = PFlags.Top | PFlags.Left,
            TopCenter       = PFlags.Top | PFlags.Center,
            TopRight        = PFlags.Top | PFlags.Right,   

            MiddleLeft      = PFlags.Middle | PFlags.Left,
            MiddleCenter    = PFlags.Middle | PFlags.Center,
            MiddleRight     = PFlags.Middle | PFlags.Right,

            BottomLeft      = PFlags.Bottom | PFlags.Left,
            BottomCenter    = PFlags.Bottom | PFlags.Center,
            BottomRight     = PFlags.Bottom | PFlags.Right
        }

        public PivotType Pivoting;

        public AnchorType XAnchoring;
        public AnchorType YAnchoring;

        public Vector2 AnchorsX;
        public Vector2 AnchorsY;

        [SerializeField]
        [FormerlySerializedAs("Offset")]
        private Vector4 _offset;

        [SerializeField]
        [FormerlySerializedAs("Pivot")]
        private Vector2 _pivot;

        [SerializeField] private Vector2 _position;

        public Vector4 Anchors
        {
            get
            {
                Vector2 x = SetupAnchoring(XAnchoring, AnchorsX);
                Vector2 y = SetupAnchoring(YAnchoring, AnchorsY);

                return new Vector4(x.x,y.x,x.y,y.y);
            }
        }

        private Vector2 SetupAnchoring(AnchorType anchoring, Vector2 free)
        {
            switch (anchoring)
            {
                case AnchorType.Stretch:
                    return new Vector2(0f, 1f);
                case AnchorType.Max:
                    return new Vector2(1f,1f);
                case AnchorType.Middle:
                    return new Vector2(0.5f, 0.5f);
                case AnchorType.Min:
                    return new Vector2(0f, 0f);
            }

            return free;
        }

        public Vector4 Offset => _offset;

        public Vector2 Pivot
        {
            get
            {
                if(Pivoting == PivotType.Free)
                    return _pivot;

                var x = 0f;
                var y = 0f;

                if (Pivoting.HasFlag(PFlags.Top))
                    y = 1f;
                else if (Pivoting.HasFlag(PFlags.Middle))
                    y = 0.5f;

                if (Pivoting.HasFlag(PFlags.Right))
                    x = 1f;
                else if (Pivoting.HasFlag(PFlags.Center))
                    x = 0.5f;

                return new Vector2(x,y);
            }
        }

        public Vector2 Position => _position;

        void Update()
        {
            var rect = transform as RectTransform;

            rect.anchorMin = new Vector2(Anchors.x, Anchors.y);
            rect.anchorMax = new Vector2(Anchors.z, Anchors.w);


            rect.offsetMin = new Vector2(Offset.x, Offset.y);
            rect.offsetMax = new Vector2(Offset.z, Offset.w);

            rect.pivot = Pivot;
            rect.anchoredPosition = Position;
        }
    }
}